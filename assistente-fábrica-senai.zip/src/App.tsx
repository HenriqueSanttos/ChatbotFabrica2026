/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef } from 'react';
import { GoogleGenAI } from "@google/genai";
import { Send, Bot, User, Loader2, Info, Calendar, Users, Target, AlertTriangle, FileText, Phone } from 'lucide-react';
import Markdown from 'react-markdown';
import { motion, AnimatePresence } from 'motion/react';

const SYSTEM_INSTRUCTION = `
NOME DO ASSISTENTE: Assistente Fábrica SENAI
TOM DE VOZ: Amigável, encorajador, claro, institucional (mas com uma pegada jovem) e direto ao ponto.

SEU OBJETIVO:
Você é o assistente virtual da III Feira de Ciência e Tecnologia – FÁBRICA SENAI 2026 ("Da ideia à solução"). Sua missão é auxiliar alunos, professores e interessados respondendo dúvidas sobre editais, submissões, regras e datas.

🚨 INSTRUÇÃO CRÍTICA E OBRIGATÓRIA (LEIA COM ATENÇÃO):
O evento acontece em 3 unidades diferentes (Rondonópolis, Alto Araguaia e Campo Verde). SEMPRE que um usuário perguntar sobre "Datas de Submissão", "Prazos" ou "Datas do Evento", você DEVE perguntar de qual unidade ele é ANTES de dar a resposta final, pois os prazos mudam.

BASE DE CONHECIMENTO:

1. Prazos de Submissão:
Regra: Se perguntarem o prazo, pergunte a cidade primeiro.
Rondonópolis: A submissão eletrônica vai de 19 de outubro a 14 de novembro de 2026.
Alto Araguaia e Campo Verde: A submissão eletrônica vai de 19 de outubro a 31 de outubro de 2026.
Onde enviar: O envio é feito exclusivamente pelo portal oficial do evento: https://www.even3.com.br/iii-fabrica-senai-686952/

2. Quem pode participar e tamanho da equipe:
Público: Restrito a alunos do 3º ano do ensino médio e discentes regularmente matriculados na aprendizagem/habilitação técnica de nível médio dos cursos de Automação, Eletrônica, Eletrotécnica, Logística, Mecânica, Mecatrônica e Saúde e Segurança do Trabalho.
Equipe: Mínimo 2 e máximo 4 alunos, além de obrigatoriamente 1 orientador(a) e 1 coorientador(a).

3. Categorias de Projetos:
O projeto deve estar ligado à área técnica do curso. Categorias: Projetos de Inovação Tecnológica (incremental, disruptiva ou radical); Soluções Industriais Aplicadas; Soluções/ modelos técnicos; Projetos Integradores; Estudos técnicos estruturados.

4. Uso de Inteligência Artificial e Plágio:
Alerta grave: O uso de IA para geração de conteúdo (textos e imagens) é ESTRITAMENTE PROIBIDO.
Consequência: Identificação de IA ou plágio leva à desqualificação imediata. O conteúdo de terceiros deve ser referenciado pela ABNT. O trabalho deve ser fruto da criatividade e esforço dos autores.

5. Datas do Evento (Feira):
Regra: Se perguntarem a data da feira, pergunte a cidade primeiro.
Rondonópolis: 9, 10, 13, 24, 25, 26, e 27 de novembro de 2026.
Alto Araguaia: 10 de novembro de 2026.
Campo Verde: 9 e 13 de novembro de 2026.

6. Formatação (Resumo e Banner):
Resumo Expandido: 5 a 8 páginas (sem numeração). Fonte Times New Roman, tamanho 12, justificado, espaçamento 1,5. Margens: Superior e Esquerda (3 cm) / Inferior e Direita (2 cm). Enviar em .docx e .pptx.
Banner: Título principal tamanho 52, demais textos em tamanho 24. Fonte Times New Roman, espaçamento simples.

7. Compras e Insumos para Protótipos:
A lista de materiais (insumos) para construção dos projetos deve ser enviada para a coordenação até o dia 27/03/2026. Após essa data, não serão feitas compras para a unidade.

8. Contato dos Organizadores:
E-mail Geral: fabricasenai@gmail.com
Organizadores: Henrique Santos (henrique.santos@senaimt.ind.br), Silvia Cangussu (silvia.cangussu@senaimt.ind.br), Wildmis Soares (wildmis.soares@senaimt.ind.br).
`;

const WELCOME_MESSAGE = `Olá! 🤖 Sou o assistente virtual da III Feira de Ciência e Tecnologia – FÁBRICA SENAI 2026: Da ideia à solução! 💡⚙️
Estou aqui para tirar todas as suas dúvidas sobre o edital, submissões, regras e datas. Para começarmos, sobre o que você gostaria de saber? (Digite o número ou o assunto)

1️⃣ Prazos de submissão
2️⃣ Quem pode participar e equipes
3️⃣ Categorias dos projetos
4️⃣ Regras sobre Inteligência Artificial
5️⃣ Datas da Feira
6️⃣ Formatação de Resumo e Banner
7️⃣ Falar com os organizadores`;

interface Message {
  role: 'user' | 'model';
  text: string;
}

export default function App() {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', text: WELCOME_MESSAGE }
  ]);
  const [input, setInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const chatRef = useRef<any>(null);

  useEffect(() => {
    const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });
    chatRef.current = ai.chats.create({
      model: "gemini-3-flash-preview",
      config: {
        systemInstruction: SYSTEM_INSTRUCTION,
      },
    });
  }, []);

  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || isLoading) return;

    const userMessage = input.trim();
    setInput('');
    setMessages(prev => [...prev, { role: 'user', text: userMessage }]);
    setIsLoading(true);

    try {
      if (!chatRef.current) {
        throw new Error("Chat not initialized");
      }

      const response = await chatRef.current.sendMessage({ message: userMessage });
      const text = response.text;
      
      if (text) {
        setMessages(prev => [...prev, { role: 'model', text }]);
      }
    } catch (error) {
      console.error("Error sending message:", error);
      setMessages(prev => [...prev, { role: 'model', text: "Desculpe, tive um problema ao processar sua mensagem. Tente novamente em instantes." }]);
    } finally {
      setIsLoading(false);
    }
  };

  const quickActions = [
    { id: '1', label: 'Prazos', icon: <Calendar className="w-4 h-4" /> },
    { id: '2', label: 'Equipes', icon: <Users className="w-4 h-4" /> },
    { id: '3', label: 'Categorias', icon: <Target className="w-4 h-4" /> },
    { id: '4', label: 'Regras IA', icon: <AlertTriangle className="w-4 h-4" /> },
    { id: '5', label: 'Datas Feira', icon: <Info className="w-4 h-4" /> },
    { id: '6', label: 'Formatação', icon: <FileText className="w-4 h-4" /> },
    { id: '7', label: 'Contatos', icon: <Phone className="w-4 h-4" /> },
  ];

  return (
    <div className="flex flex-col h-screen bg-[#F8F9FA] font-sans text-slate-900">
      {/* Header */}
      <header className="bg-white border-b border-slate-200 px-6 py-4 flex items-center justify-between sticky top-0 z-10 shadow-sm">
        <div className="flex items-center gap-3">
          <div className="bg-blue-600 p-2 rounded-lg">
            <Bot className="text-white w-6 h-6" />
          </div>
          <div>
            <h1 className="font-bold text-lg leading-tight">Fábrica SENAI 2026</h1>
            <p className="text-xs text-slate-500 font-medium uppercase tracking-wider">Assistente Virtual</p>
          </div>
        </div>
        <div className="hidden sm:flex items-center gap-2 text-xs font-semibold text-slate-400 uppercase tracking-widest">
          <span className="w-2 h-2 bg-emerald-500 rounded-full animate-pulse"></span>
          Online
        </div>
      </header>

      {/* Chat Area */}
      <main className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 max-w-4xl mx-auto w-full">
        <AnimatePresence initial={false}>
          {messages.map((msg, idx) => (
            <motion.div
              key={idx}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div className={`flex gap-3 max-w-[85%] ${msg.role === 'user' ? 'flex-row-reverse' : 'flex-row'}`}>
                <div className={`w-8 h-8 rounded-full flex items-center justify-center flex-shrink-0 mt-1 ${
                  msg.role === 'user' ? 'bg-slate-200' : 'bg-blue-100'
                }`}>
                  {msg.role === 'user' ? <User className="w-4 h-4 text-slate-600" /> : <Bot className="w-4 h-4 text-blue-600" />}
                </div>
                <div className={`rounded-2xl px-4 py-3 shadow-sm ${
                  msg.role === 'user' 
                    ? 'bg-blue-600 text-white rounded-tr-none' 
                    : 'bg-white border border-slate-200 text-slate-800 rounded-tl-none'
                }`}>
                  <div className="markdown-body prose prose-slate prose-sm max-w-none">
                    <Markdown>{msg.text}</Markdown>
                  </div>
                </div>
              </div>
            </motion.div>
          ))}
        </AnimatePresence>
        {isLoading && (
          <motion.div initial={{ opacity: 0 }} animate={{ opacity: 1 }} className="flex justify-start">
            <div className="flex gap-3 items-center bg-white border border-slate-200 rounded-2xl px-4 py-3 shadow-sm">
              <Loader2 className="w-4 h-4 text-blue-600 animate-spin" />
              <span className="text-sm text-slate-500 font-medium">Pensando...</span>
            </div>
          </motion.div>
        )}
        <div ref={messagesEndRef} />
      </main>

      {/* Footer / Input */}
      <footer className="bg-white border-t border-slate-200 p-4 md:p-6 sticky bottom-0">
        <div className="max-w-4xl mx-auto space-y-4">
          {/* Quick Actions */}
          <div className="flex gap-2 overflow-x-auto pb-2 scrollbar-hide no-scrollbar">
            {quickActions.map(action => (
              <button
                key={action.id}
                onClick={() => {
                  setInput(action.label);
                }}
                className="flex items-center gap-2 bg-slate-50 hover:bg-slate-100 border border-slate-200 rounded-full px-4 py-2 text-xs font-semibold text-slate-600 transition-colors whitespace-nowrap"
              >
                {action.icon}
                {action.label}
              </button>
            ))}
          </div>

          {/* Input Box */}
          <div className="relative flex items-center">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleSend()}
              placeholder="Digite sua dúvida aqui..."
              className="w-full bg-slate-50 border border-slate-200 rounded-2xl pl-5 pr-14 py-4 focus:outline-none focus:ring-2 focus:ring-blue-500/20 focus:border-blue-500 transition-all text-slate-800"
            />
            <button
              onClick={handleSend}
              disabled={!input.trim() || isLoading}
              className="absolute right-2 p-3 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-300 text-white rounded-xl transition-all shadow-md active:scale-95"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <p className="text-[10px] text-center text-slate-400 font-medium uppercase tracking-widest">
            III Feira de Ciência e Tecnologia – FÁBRICA SENAI 2026
          </p>
        </div>
      </footer>

      <style>{`
        .scrollbar-hide::-webkit-scrollbar {
          display: none;
        }
        .scrollbar-hide {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
        .markdown-body p {
          margin-bottom: 0.5rem;
        }
        .markdown-body p:last-child {
          margin-bottom: 0;
        }
        .markdown-body ul {
          list-style-type: disc;
          padding-left: 1.25rem;
          margin-bottom: 0.5rem;
        }
        .markdown-body ol {
          list-style-type: decimal;
          padding-left: 1.25rem;
          margin-bottom: 0.5rem;
        }
      `}</style>
    </div>
  );
}
